package com.example.webview.ui.webview

import androidx.lifecycle.ViewModel

class WebViewViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}